DOW = input("Enter the Day Of WEEK: ").lower()  # Convert input to lowercase
print(DOW)

if DOW == "sunday" or DOW == "saturday":  # Use "==" comparison operator
    print("I will learn LIVE DevOps")  # If condition is true
else:  # If condition is false
    print("I will practice DevOps")

