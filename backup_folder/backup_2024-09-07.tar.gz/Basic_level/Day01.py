"""
#Muje Python Nahi Athi TILL 05/09/2024-5:21AM
Here’s a LIVE Workshop for you on 1st September 9 A.M (Sunday) covering these things:

 - 1. Introduction to Python for DevOps

 - 2. Essential Python Syntax and Concepts
	-> conditionals
	-> Loops
	-> data structuer -> [list, dictionary]
	-> function


 - 3. Automating Tasks with Python Scripts

 - 4. Python Libraries for DevOps

 - 5. Handling Files and Data Streams

 - 6. Python for Cloud and Infrastructure

 - 7. Q&A and Hands-On Practice

 - 8. Conclusion and Resources

"""
name=input("enter your name: ") #User se input le sakte hai
name="Yesh" #variable = vary ho sakta hai vari + able
env="dev" # dev = constant , env = variable
print("HEllO",name)

